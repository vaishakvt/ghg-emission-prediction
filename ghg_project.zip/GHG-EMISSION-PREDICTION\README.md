# GHG Emission Prediction Using Supply Chain Data

## 📌 Project Overview
This project predicts Supply Chain Emission Factors with Margins using annual data from 2010–2016. The data includes descriptive and quality metrics like substance, unit, reliability, temporal, geographical, technological correlation, and data collection methods.

## 📁 Files Included
- `week2-ghg-analysis.ipynb`: Full code from loading data to saving the trained model.
- `ghg_model.pkl`: Final saved model using RandomForestRegressor.
- `requirements.txt`: List of Python libraries used.

## ⚙️ Libraries Required
```bash
pandas
numpy
seaborn
matplotlib
scikit-learn
joblib
import joblib
model = joblib.load('ghg_model.pkl')